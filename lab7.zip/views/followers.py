from flask import Response, request
from flask_restful import Resource
from models import Following
import json

def get_path():
    return request.host_url + 'api/posts/'

class FollowerListEndpoint(Resource):
    def __init__(self, current_user):
        self.current_user = current_user
    
    def get(self):
        user_id = self.current_user.id
        '''
        posts = Post.query.filter(
            Post.user_id.in_(user_ids)).limit(limit).all()
        posts_json = [post.to_dict() for post in posts]

        People who are following the current user.
        In other words, select user_id where following_id = current_user.id
        '''
        followers = Following.query.filter(
            Following.following_id.__eq__(user_id)).all()

        followers_json = [f.to_dict_follower() for f in followers]
        # print(followers_json)

        return Response(json.dumps(followers_json), mimetype="application/json", status=200)


def initialize_routes(api):
    api.add_resource(
        FollowerListEndpoint, 
        '/api/followers', 
        '/api/followers/', 
        resource_class_kwargs={'current_user': api.app.current_user}
    )
