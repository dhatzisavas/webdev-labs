from os import times_result
from flask import Response, request
from flask_restful import Resource
from models import Bookmark, db, Post
import json

from views import can_view_post, get_authorized_user_ids


class BookmarksListEndpoint(Resource):

    def __init__(self, current_user):
        self.current_user = current_user

    def get(self):
        # get all bookmarks owned by the current user
        bookmarks = Bookmark.query.filter(
            Bookmark.user_id.__eq__(self.current_user.id))
        for b in bookmarks:
            print(b)
        bks_json = [bk.to_dict() for bk in bookmarks]
        return Response(json.dumps(bks_json), mimetype="application/json", status=200)

    def post(self):
        # create a new "bookmark" based on the data posted in the body
        body = request.get_json()
        post = body.get("post_id")
        
        if not post:
            return Response(json.dumps({"message": "no post id given"}), mimetype="application/json", status=400)
        try:
            post = int(post)
        except:
            return Response(json.dumps({"message": "invalid parameters"}), mimetype="application/json", status=400)
        if not can_view_post(post, self.current_user):
            return Response(json.dumps({"message": "post not found"}), mimetype="application/json", status=404)
        # other = Bookmark.query.filter(
        #     (Bookmark.user_id == self.current_user.id) and (Bookmark.post_id == post)).all()
        other = Bookmark.query.filter_by(user_id=self.current_user.id).filter_by(post_id=post).all()
        print(other)
        if other:
            return Response(json.dumps({"message": "bookmark already exists"}), mimetype="application/json", status=400)
        try:
            new_bk = Bookmark(self.current_user.id, post)
        except:
            return Response(json.dumps({"message": "invalid parameters"}), mimetype="application/json", status=400)

        # if not new_bk.post:
        #     return Response(json.dumps({"message": "post does not exist"}), mimetype="application/json", status=404)

        

        db.session.add(new_bk)
        db.session.commit()
        return Response(json.dumps(new_bk.to_dict()), mimetype="application/json", status=201)


class BookmarkDetailEndpoint(Resource):

    def __init__(self, current_user):
        self.current_user = current_user

    def delete(self, id):
        # delete "bookmark" record where "id"=id
        user_id = self.current_user.id

        try:
            bk = Bookmark.query.get(id)
        except:
            return Response(json.dumps({"message": "bookmark id does not exist"}), mimetype="application/json", status=404)

        if not bk:
            return Response(json.dumps({"message": "bookmark id does not exist"}), mimetype="application/json", status=404)

        if bk.user_id != user_id:
            return Response(json.dumps({"message": "unauthorized access"}), mimetype="application/json", status=404)

        try:
            Bookmark.query.filter_by(id=id).delete()
        except:
            return Response(json.dumps({"message": "post id does not exist"}), mimetype="application/json", status=404)

        db.session.commit()
        return Response(json.dumps({}), mimetype="application/json", status=200)


def initialize_routes(api):
    api.add_resource(
        BookmarksListEndpoint,
        '/api/bookmarks',
        '/api/bookmarks/',
        resource_class_kwargs={'current_user': api.app.current_user}
    )

    api.add_resource(
        BookmarkDetailEndpoint,
        '/api/bookmarks/<int:id>',
        '/api/bookmarks/<int:id>',
        resource_class_kwargs={'current_user': api.app.current_user}
    )
