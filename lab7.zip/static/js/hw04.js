const story2Html = story => {
    return `
        <div class = "story">
            <img src="${story.user.thumb_url}" class="pic" alt="${story.title}" />
            <p>${story.user.username}</p>
        </div>
    `
};

// fetch data from your API endpoint:
const displayStories = () => {
    fetch('/api/stories')
        .then(response => response.json())
        .then(stories => {
            const html = stories.map(story2Html).join('\n');
            document.querySelector('.stories').innerHTML = html;
        })
};

const user2Html = user =>
    `
    <div class="rec">
        <img src="${user.thumb_url}" alt="profile picture for " ${user.username}">
        <div class="name">
            <p>${user.username}</p>
            <p class="suggestions">suggested for you</p>
        </div>
        <button class = "follow"
        aria-label = "follow"
        aria-checked = "false" data-user-id = ${user.id} onclick="toggleFollow(event)">follow</button>
    </div>
    `

const getSuggestions = () =>
    fetch("https://cs396-photo-app-911.herokuapp.com/api/suggestions/")
        .then(reponse => reponse.json())
        .then(users => {
            console.log(users)
            document.querySelector('#sug').innerHTML = users.map(user2Html).join('\n')
        })

const renderProfile = prof =>
    `
        
    <img src="${prof.image_url}", alt = "my profile pic">
    <h2>
        ${prof.username}
    </h2>
        `

const renderCards = c =>
    `
<div class="card">
    <div class="posttop">
        <h3>${c.user.username}</h3>
        <i class="fas fa-ellipsis-h"></i>
    </div>
    <img src=${c.image_url} alt="post by user ${c.user.username}">
    <div class="buttons">
        <i class="far fa-heart"></i>
        <i class="far fa-comment"></i>
        <i class="far fa-paper-plane"></i>
        <div id="bk">
            <i class="far fa-bookmark"></i>
        </div>
    </div>
    <div class="info">
        <p id="like">{{c.likes}} likes</p>
        <p>
            <b>${c.user.username}</b> ${c.title}.. <a href="#">more</a>
        </p>
        {% if c.comments | length == 1%}
        <p><b>${c.comments[0].user.username}</b> ${c.comments[0].text}</p>
        {%elif c.comments | length > 1 %}

        <p id="viewall"><a href="">View all ${c.comments | length} comments </a></p>
        <p><b>${c.comments[0].user.username}</b> ${c.comments[0].text}</p>
        {% endif%}



        <!-- <p id="date">1 DAY AGO</p> -->
    </div>
    <hr>

    <div class="comments">
        <i class="far fa-smile"></i>
        <input type="text" id="phone" name="phone" placeholder="Add a comment..." aria-label="Post comment">
        <a href="#">Post</a>
    </div>
</div>`

const displayCards = () =>
    fetch("https://cs396-photo-app-911.herokuapp.com/api/posts/?limit=50")
        .then(response => response.json())
        .then(card =>
            document.querySelector(".posts").innerHTML = card.map(renderCards).join('\n'))

const displayProfile = () =>
    fetch("https://cs396-photo-app-911.herokuapp.com/api/profile/")
        .then(response => response.json())
        .then(prof =>
            document.querySelector('.self').innerHTML = renderProfile(prof))

const createFollower = (userId, elem) => {
    const postData = {
        "user_id": userId
    }
    console.log(postData)

    fetch("https://cs396-photo-app-911.herokuapp.com/api/following/",
        {
            method: "POST",
            headers: { 'Content-Type': 'application/json', },
            body: JSON.stringify(postData)
        })
        .then(response => response.json())
        .then(data => {
            elem.innerHTML = 'unfollow'
            elem.classList.add('unfollow')
            elem.classList.remove('follow')
            elem.setAttribute('data-following-id', data.id)
            elem.setAttribute('aria-checked', true)
        })
}

const deleteFollower = (followingId, elem) => {
    const deleteURL = `https://cs396-photo-app-911.herokuapp.com/api/following/${followingId}`
    fetch(deleteURL, {method: 'DELETE'})
    .then(response => response.json())
    .then(date => {
        elem.innerHTML = 'follow'
        elem.classList.add('follow')
        elem.classList.remove('unfollow')
        elem.removeAttribute('data-following-id')
        elem.setAttribute('aria-checked', false)
    })
}


const toggleFollow = ev => {
    const elem = ev.currentTarget
    console.log(elem.dataset)
    elem.innerHTML === 'follow'
        ? createFollower(elem.dataset.userId, elem)
        : deleteFollower(elem.dataset.followingId, elem)
}

const initPage = () => {
    displayStories();
    getSuggestions()
    displayProfile()
    displayCards();
};

// invoke init page to display stories:
initPage();
// getSuggestions()


