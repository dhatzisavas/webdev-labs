from flask import Response, request
from flask_restful import Resource
from models import Post, db, Following
from views import get_authorized_user_ids

import json


def get_path():
    return request.host_url + 'api/posts/'


class PostListEndpoint(Resource):

    def __init__(self, current_user):
        self.current_user = current_user

    def get(self):  # HTTP GET
        args = request.args
        print(args)
        # Goal: limit to only user #12 (current_user)'s network
        #   - oneself
        #   - ppl #12 are following

        # 1. Query the following table to get the user_ids that #12 is following:
        # user_ids_tuples = (
        #     db.session
        #         .query(Following.following_id)
        #         .filter(Following.user_id == self.current_user.id)
        #         .order_by(Following.following_id)
        #         .all()
        #     )
        # print(user_ids_tuples)
        user_ids = get_authorized_user_ids(self.current_user)
        # print(user_ids)
        # user_ids.append(self.current_user.id)

        # alternative method
        # user_ids = get_authorized_user_ids(self.current_user)
        try:
            limit = int(args.get('limit') or 20)  # 20 is the default
        except:
            return Response(json.dumps({"message": "the limit parameter is invalid"}), mimetype="application/json", status=400)
        if limit > 50:
            return Response(json.dumps({"message": "the limit parameter is too large"}), mimetype="application/json", status=400)
        #posts = Post.query.limit(limit).all()
        posts = Post.query.filter(
            Post.user_id.in_(user_ids)).limit(limit).all()
        posts_json = [post.to_dict(user=self.current_user) for post in posts]
        return Response(json.dumps(posts_json), mimetype="application/json", status=200)

    def post(self):  # HTTP POST
        # create a new post based on the data posted in the body
        body = request.get_json()

        new_post = Post(
            image_url=body.get('image_url'),
            user_id=self.current_user.id,
            caption=body.get('caption'),
            alt_text=body.get('alt_text')
        )

        if not new_post.image_url:
            return Response(json.dumps({"message": "image_url missing"}), mimetype="application/json", status=400)

        db.session.add(new_post)
        db.session.commit()
        return Response(json.dumps(new_post.to_dict()), mimetype="application/json", status=201)


class PostDetailEndpoint(Resource):

    def __init__(self, current_user):
        self.current_user = current_user

    def patch(self, id):
        # args = request.args
        # print(args)
        # update post based on the data posted in the body
        body = request.get_json()
        print(body)
        user_ids = get_authorized_user_ids(self.current_user)
        # user_ids = get_authorized_user_ids(self.current_user)
        # if not id in user_ids:
        #     return Response(json.dumps({"message" : "post id does not exist"}), mimetype="application/json", status=404)
        # try:
        post = Post.query.get(id)
        # except:
        #     return Response(json.dumps({"message": "post id does not exist"}), mimetype="application/json", status=404)

        if not post:
            return Response(json.dumps({"message": "post does not exist"}), mimetype="application/json", status=404)

        if post.user_id != self.current_user.id:
            return Response(json.dumps({"message": "unauthorized access"}), mimetype="application/json", status=404)

        post.image_url = body.get('image_url') or post.image_url
        post.caption = body.get('caption') or post.caption
        post.alt_text = body.get('alt_text') or post.alt_text

        # # commit changes:
        db.session.commit()
        return Response(json.dumps(post.to_dict()), mimetype="application/json", status=200)

    def delete(self, id):
        # delete post where "id"=id
        user_id = self.current_user.id
        # print("here!")
        # print(user_id)
        # print(Post.query.get(id).user_id)

        try:
            post = Post.query.get(id)
        except:
            print("except1")
            return Response(json.dumps({"message": "post id does not exist"}), mimetype="application/json", status=404)

        if not post:
            print("except2")
            return Response(json.dumps({"message": "post does not exist"}), mimetype="application/json", status=404)

        if post.user_id != user_id:
            print("except3")
            return Response(json.dumps({"message": "unauthorized access"}), mimetype="application/json", status=404)

        try:
            Post.query.filter_by(id=id).delete()
        except:
            print("except4")
            return Response(json.dumps({"message": "post id does not exist"}), mimetype="application/json", status=404)

        db.session.commit()
        return Response(json.dumps({}), mimetype="application/json", status=200)

    def get(self, id):
        # get the post based on the id
        user_ids = get_authorized_user_ids(self.current_user)
        print (user_ids)
        try:
            post = Post.query.get(id)
            # print(post.user.id)
        except:
            return Response(json.dumps({"message": "post id does not exist"}), mimetype="application/json", status=404)
        if not post:
            return Response(json.dumps({"message": "post id does not exist"}), mimetype="application/json", status=404)
        if post.user_id in user_ids:
            return Response(json.dumps(post.to_dict(user=self.current_user)), mimetype="application/json", status=200)

        return Response(json.dumps({"message": "unauthorized access"}), mimetype="application/json", status=404)

        


def initialize_routes(api):
    api.add_resource(
        PostListEndpoint,
        '/api/posts', '/api/posts/',
        resource_class_kwargs={'current_user': api.app.current_user}
    )
    api.add_resource(
        PostDetailEndpoint,
        '/api/posts/<int:id>', '/api/posts/<int:id>/',
        resource_class_kwargs={'current_user': api.app.current_user}
    )
