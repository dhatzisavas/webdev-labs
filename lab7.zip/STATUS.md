## Done:
* stories
* posts
* suggestions
* profile
* followers
* comments
* post_likes 
* bookmarks

## To do:
* following (all but get)

