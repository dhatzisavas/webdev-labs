from flask import Response, request
from flask_restful import Resource
from models import Following, User, db
import json

from tests.utils import get_authorized_user_ids


def get_path():
    return request.host_url + 'api/posts/'


class FollowingListEndpoint(Resource):
    def __init__(self, current_user):
        self.current_user = current_user

    def get(self):
        # return all of the "following" records that the current user is following
        followers = Following.query.filter(
            Following.user_id == self.current_user.id).all()
        user_ids_tuples = (
            db.session
            .query(Following)
            .filter(Following.user_id == self.current_user.id)
            .order_by(Following.following_id)
            .all()
        )
        return Response(json.dumps([f.to_dict_following() for f in user_ids_tuples]), mimetype="application/json", status=200)

    def post(self):
        body = request.get_json()
        follow_user_id = body.get("user_id")
        try:
            follow_user_id = int(follow_user_id)
        except:
            return Response(json.dumps({"message": "invalid parameters"}), mimetype="application/json", status=400)
        current_following = Following.query.filter_by(user_id = self.current_user.id).filter_by(following_id=follow_user_id).all()
        if current_following:
            return Response(json.dumps({"message": "already following"}), mimetype="application/json", status=400)
        following_exist = User.query.get(follow_user_id)
        if not following_exist:
            return Response(json.dumps({"message": "user does not exist"}), mimetype="application/json", status=404)
        new_following = Following(self.current_user.id, follow_user_id)
        db.session.add(new_following)
        db.session.commit()
        return Response(json.dumps(new_following.to_dict_following()), mimetype="application/json", status=201)


class FollowingDetailEndpoint(Resource):
    def __init__(self, current_user):
        self.current_user = current_user

    def delete(self, id):
        # delete "following" record where "id"=id
        try:
            f = Following.query.get(id)
        except:
            return Response(json.dumps({"message": "failed to get following"}), mimetype="application/json", status=404)
        if not f:
            return Response(json.dumps({"message": "not found"}), mimetype="application/json", status=404)
        if not f.user_id == self.current_user.id:
            return Response(json.dumps({"message": "not authorized"}), mimetype="application/json", status=404)
        try:
            Following.query.filter_by(id=id).delete()
        except:
            return Response(json.dumps({"message": "can't delete"}), mimetype="application/json", status=404)
        db.session.commit()
        return Response(json.dumps({}), mimetype="application/json", status=200)


def initialize_routes(api):
    api.add_resource(
        FollowingListEndpoint,
        '/api/following',
        '/api/following/',
        resource_class_kwargs={'current_user': api.app.current_user}
    )
    api.add_resource(
        FollowingDetailEndpoint,
        '/api/following/<int:id>',
        '/api/following/<int:id>/',
        resource_class_kwargs={'current_user': api.app.current_user}
    )
