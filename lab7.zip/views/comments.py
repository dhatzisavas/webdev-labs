from flask import Response, request
from flask_restful import Resource
import json
from models import db, Comment, Post
from tests.utils import get_authorized_user_ids
from views import can_view_post

class CommentListEndpoint(Resource):

    def __init__(self, current_user):
        self.current_user = current_user
    
    def post(self):
        # create a new "Comment" based on the data posted in the body 
        body = request.get_json()
        post_id = body.get('post_id')
        text = body.get('text')
        try:
            comment = Comment(text, self.current_user.id, post_id)
        except:
            return Response(json.dumps({"message" : "invalid post_id"}), mimetype="application/json", status=400)
        if not comment.text:
            return Response(json.dumps({"message" : "no text provided"}), mimetype="application/json", status=400)
        if not can_view_post(post_id, self.current_user):
            return Response(json.dumps({"message" : "can't access post"}), mimetype="application/json", status=404)
        db.session.add(comment)
        db.session.commit()
        return Response(json.dumps(comment.to_dict()), mimetype="application/json", status=201)
        
class CommentDetailEndpoint(Resource):

    def __init__(self, current_user):
        self.current_user = current_user
  
    def delete(self, id):
        try:
            commt = Comment.query.get(id)
        except:
            return Response(json.dumps({"message" : "comment does not exist"}), mimetype="application/json", status=400)
        if not commt:
            return Response(json.dumps({"message" : "comment does not exist"}), mimetype="application/json", status=404)
        if not commt.user_id == self.current_user.id:
            return Response(json.dumps({"message" : "cannot access post"}), mimetype="application/json", status=404)
        Comment.query.filter_by(id=id).delete()
        
        db.session.commit()
        return Response(json.dumps({}), mimetype="application/json", status=200)


def initialize_routes(api):
    api.add_resource(
        CommentListEndpoint, 
        '/api/comments', 
        '/api/comments/',
        resource_class_kwargs={'current_user': api.app.current_user}

    )
    api.add_resource(
        CommentDetailEndpoint, 
        '/api/comments/<int:id>', 
        '/api/comments/<int:id>/',
        resource_class_kwargs={'current_user': api.app.current_user}
    )
